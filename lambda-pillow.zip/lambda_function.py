from PIL import Image
import boto3
import os

s3 = boto3.client('s3')

def lambda_handler(event, context):
    input_bucket = event['Records'][0]['s3']['bucket']['name']
    input_key = event['Records'][0]['s3']['object']['key']
    output_bucket = os.environ['OUTPUT_BUCKET']
    output_key = f"resized-{input_key}"

    s3.download_file(input_bucket, input_key, '/tmp/input.jpg')
    img = Image.open('/tmp/input.jpg')
    img = img.resize((128, 128))
    img.save('/tmp/output.jpg')

    s3.upload_file('/tmp/output.jpg', output_bucket, output_key)
    return {"status": "Image resized and uploaded."}
